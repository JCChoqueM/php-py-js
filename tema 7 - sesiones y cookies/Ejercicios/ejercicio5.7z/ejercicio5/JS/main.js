// Código principal que se ejecuta al cargar la página
mostrarProductos();
mostrarCarritoJS();
cargarCarritoPHP();
