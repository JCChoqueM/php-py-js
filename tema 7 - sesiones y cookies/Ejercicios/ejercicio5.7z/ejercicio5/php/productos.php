<?php
$productos = [
  'patitoBatman' => ['nombre' => 'Patito Batman', 'precio' => 54],
  'patitoSuperman' => ['nombre' => 'Patito Superman', 'precio' => 40],
  'patitoJoker' => ['nombre' => 'Patito Joker', 'precio' => 18],
  'patitoRobin' => ['nombre' => 'Patito Robin', 'precio' => 10],
];
